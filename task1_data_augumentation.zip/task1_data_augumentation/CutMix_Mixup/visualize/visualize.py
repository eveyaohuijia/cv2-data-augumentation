
import torchvision
import torchvision.transforms as transforms
import torch
import numpy as np

def img_save(tensor,filename):
    unloader = transforms.ToPILImage()
    image = tensor.cpu().clone()  # clone the tensor
    image = image.squeeze(0)  # remove the fake batch dimension
    image = unloader(image)
    image.save(filename,quality=95)

transform_train = transforms.Compose([
            transforms.ToTensor()
        ])


dataset = torchvision.datasets.CIFAR100(root='./data', train=True, download=False, transform=transform_train)
dataloader = torch.utils.data.DataLoader(dataset, batch_size=32, shuffle=False, num_workers=2)


def mixup_data(x, y, alpha=1.0, use_cuda=True):
    '''Returns mixed inputs, pairs of targets, and lambda'''
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    if use_cuda:
        index = torch.randperm(batch_size).cuda()
    else:
        index = torch.randperm(batch_size)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def rand_bbox(size, lam):
    W = size[2]
    H = size[3]
    cut_rat = np.sqrt(1. - lam)
    cut_w = np.int(W * cut_rat)
    cut_h = np.int(H * cut_rat)

    # uniform
    cx = np.random.randint(W)
    cy = np.random.randint(H)

    bbx1 = np.clip(cx - cut_w // 2, 0, W)
    bby1 = np.clip(cy - cut_h // 2, 0, H)
    bbx2 = np.clip(cx + cut_w // 2, 0, W)
    bby2 = np.clip(cy + cut_h // 2, 0, H)

    return bbx1, bby1, bbx2, bby2
def cutmix_data(x, y, alpha=1.0, use_cuda=True):
    '''Returns mixed inputs, pairs of targets, and lambda'''
    r = np.random.rand(1)
    if alpha > 0 and r < 0.5:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    if use_cuda:
        index = torch.randperm(batch_size).cuda()
    else:
        index = torch.randperm(batch_size)

    bbx1, bby1, bbx2, bby2 = rand_bbox(x.size(), lam)
    x[:, :, bbx1:bbx2, bby1:bby2] = x[index, :, bbx1:bbx2, bby1:bby2]
    # adjust lambda to exactly match pixel ratio
    lam = 1 - ((bbx2 - bbx1) * (bby2 - bby1) / (x.size()[-1] * x.size()[-2]))

    y_a, y_b = y, y[index]
    return x, y_a, y_b, lam

def Cutout_data(x, y, alpha=1.0, use_cuda=True):
    return x,y,y,1.0


for images, labels in dataloader:
    images_mixup, labels_a, labels_b, lam = mixup_data(images, labels)
    images_cutmix, labels_a, labels_b, lam = cutmix_data(images, labels)
    for i in range(0,10):
        filename = 'Sample_' + str(i) + '.png'
        img_save(images[i], filename)

        filename_cutmix = 'cutmix_' + str(i) + '.png'
        img_save(images_cutmix[i], filename_cutmix)

        filename_mixup = 'mixup_' + str(i) + '.png'
        img_save(images_mixup[i], filename_mixup)
    break

