
import torchvision
import torchvision.transforms as transforms
import torch
import numpy as np
from torchtoolbox.transform import Cutout

def img_save(tensor,filename):
    unloader = transforms.ToPILImage()
    image = tensor.cpu().clone()  # clone the tensor
    image = image.squeeze(0)  # remove the fake batch dimension
    image = unloader(image)
    image.save(filename,quality=95)

transform_cutout = transforms.Compose([
            transforms.ToTensor(),
            Cutout()
        ])

cutoutset = torchvision.datasets.CIFAR100(root='./data', train=True, download=False, transform=transform_cutout)
cutoutloader = torch.utils.data.DataLoader(cutoutset, batch_size=3, shuffle=False, num_workers=2)




for images, labels in cutoutloader:
    for i in range(10):
        filename = 'cotout_' + str(i) + '.png'
        img_save(images[i], filename)
    break